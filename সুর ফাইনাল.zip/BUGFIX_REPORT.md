# SurProAIMusic — Static Code Review & Bug Fixes

Reviewed all 88 Kotlin files (~2,900 lines) across DI, data, domain, and UI layers, plus
the Gradle build files and Android manifest. No Android SDK/emulator was available in
this environment, so this was a manual static review rather than an actual `gradle
build` — but every issue below was traced to a specific line and is a genuine defect,
not a guess.

## Compile-breaking bugs (the project could not have built as-is)

1. **Entire `ui/theme` package was missing.** `Color.kt`, `Type.kt`, `Theme.kt` — and
   the `SurProAIMusicTheme` composable they define — didn't exist anywhere in any of
   the 5 phases, yet every single screen file and `MainActivity` imports and uses it.
   **Fixed:** added a standard Material3 theme package.

2. **Entire `res/` directory was missing.** No `strings.xml`, `themes.xml`,
   `backup_rules.xml`, `data_extraction_rules.xml`, or launcher icons — all referenced
   directly in `AndroidManifest.xml`. **Fixed:** added minimal versions of each plus a
   simple vector adaptive launcher icon.

3. **`MainActivity.kt`: a `data class` declaration sat between two import
   statements.** Kotlin requires all imports to precede any other top-level
   declaration — this alone is a hard syntax error. It also imported individual icon
   properties (`filled.Mic`, etc.) but referenced them as `Icons.Filled.Mic`, which
   additionally needs `androidx.compose.material.icons.Icons` imported (it wasn't), and
   was missing imports for `SocialFeedScreen`, `MarketplaceScreen`, and
   `Modifier.padding`. **Fixed:** reordered the file and added the missing imports.

4. **`PaymentReviewScreen.kt`: a raw carriage-return byte (`\r`) sat in place of the
   letter "r"** in the lambda parameter `requestId`, i.e. the file literally contained
   `{ <CR>equestId, status -> ... }`. This is binary corruption, not a typo, and is an
   automatic parse error. **Fixed:** restored `requestId`.

5. **`LyricsGeneratorScreen.kt`: a literal two-character `\n` (backslash + n) sat in
   the source** instead of an actual newline/space in `Scaffold(...) {\n
   paddingValues -> ...}`. **Fixed:** replaced with a normal space.

6. **`DatabaseModule.kt` never provided `MarketplaceDao` or `UserDao`**, even though
   `MarketplaceRepositoryImpl` and `AdminRepositoryImpl` inject them — Hilt would fail
   with "cannot be provided without an `@Provides`-annotated method." **Fixed:** added
   both provider methods and their imports.

7. **`AppDatabase.kt` referenced `SocialPostDao`, `MarketplaceDao`, and `PaymentDao`
   without importing them** (they live in different sub-packages) — three unresolved
   references. **Fixed:** added the imports.

8. **`RepositoryModule.kt` never bound `MarketplaceRepository`** to its
   implementation, even though `MarketplaceViewModel`, `UploadBeatUseCase`, and
   `UploadLyricsUseCase` all inject the interface — a Hilt `MissingBinding` error.
   **Fixed:** added the `@Binds` method.

9. **`app/build.gradle.kts` used `kapt(...)` dependencies for the Hilt and Room
   annotation processors but never applied the `kotlin-kapt` Gradle plugin.** Without
   it, the `kapt` dependency configuration doesn't exist and the build fails
   immediately. **Fixed:** added `id("org.jetbrains.kotlin.kapt")` to the app module
   and declared its version in the root `build.gradle.kts`.

## Logic bugs (would have compiled, but behaved incorrectly)

10. **`AdminRepositoryImpl.giftTokens()` and
    `PaymentRepositoryImpl.updatePaymentRequestStatus()` called `.collect { }` on a
    live Room `Flow` from a `SELECT ... WHERE id = :id` query.** That Flow never
    completes on its own (it keeps listening for future DB changes), so `collect`
    would suspend forever — both functions would hang indefinitely and never return.
    **Fixed:** switched to `.first()` to take a single snapshot.

11. **`VoiceRepositoryImpl` sent `"Bearer $apiKey"` as the ElevenLabs `xi-api-key`
    header value.** ElevenLabs expects the raw key with no prefix, so every
    text-to-speech call would fail authentication. **Fixed:** removed the `Bearer `
    prefix (kept for OpenAI/Suno, which do use it correctly).

12. **`SupabaseManager` used the passwordless OTP provider
    (`AuthOtp.Email`) while setting a `password` field**, which that provider doesn't
    support — a mismatch between a magic-link/OTP flow and password-based sign-in.
    **Fixed:** switched to the builtin password-based `Email` provider.

13. **`FFmpegUtil.createLyricsVideo()` had two ffmpeg issues:**
    - It ran an `overlay` filter between a video stream and an *audio* stream
      (`[v][a]overlay=...`). `overlay` composites two video streams — it can't take
      audio input, so the command would fail at runtime for every video generated.
    - It joined the argument array into one string via `FFmpegKit.execute()`, but
      `lyricsText` (actual song lyrics) will routinely contain spaces, and FFmpegKit's
      single-string mode naively tokenizes on whitespace — this would silently mangle
      argument boundaries.

    **Fixed:** removed the invalid `overlay` step (drawtext is applied directly to the
    scaled background video, and the audio track is passed through via `-map`), added
    an escaping helper for the lyrics/font-path text passed into the filter, and
    switched to `FFmpegKit.executeWithArguments()` so arguments are never re-tokenized.

## Worth double-checking (not fixed — needs verification I couldn't do offline)

- The Supabase dependency coordinates in `app/build.gradle.kts`
  (`io.github.jan-tennie:supabase-android...`) look non-standard; I wasn't able to
  reach Maven Central from this sandbox to confirm the actual published artifact IDs
  for the supabase-kt libraries. Worth checking against the library's current docs
  before building.
- `MusicGenerationRequest.model` defaults to `"suno-v3"` but the comment next to it
  says "Assuming a default model for Suno v4" — cosmetic inconsistency, didn't change
  the value since I don't know which is actually intended.

## Files changed

- `MainActivity.kt`
- `ui/theme/Color.kt`, `Theme.kt`, `Type.kt` (new)
- `res/values/strings.xml`, `themes.xml`, `res/xml/backup_rules.xml`,
  `data_extraction_rules.xml`, `res/mipmap-anydpi-v26/ic_launcher*.xml`,
  `res/drawable/ic_launcher_*.xml` (new)
- `app/proguard-rules.pro` (new)
- `ui/paymentreview/PaymentReviewScreen.kt`
- `ui/lyricsgen/LyricsGeneratorScreen.kt`
- `di/DatabaseModule.kt`
- `data/local/AppDatabase.kt`
- `di/RepositoryModule.kt`
- `app/build.gradle.kts`, root `build.gradle.kts`
- `data/repository/admin/AdminRepositoryImpl.kt`
- `data/repository/payment/PaymentRepositoryImpl.kt`
- `data/repository/VoiceRepositoryImpl.kt`
- `SupabaseManager.kt`
- `utils/FFmpegUtil.kt`
