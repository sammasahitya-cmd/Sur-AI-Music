package com.surpro.aimusic.feature.payment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PaymentScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Choose Payment Method", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        PaymentOption("bKash", "Pay via bKash Wallet")
        PaymentOption("Nagad", "Pay via Nagad Wallet")
        PaymentOption("Rocket", "Pay via Rocket Wallet")
        PaymentOption("Credit/Debit Card", "Stripe Payment Gateway")
        PaymentOption("Google Pay", "Google Play In-App Purchase")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentOption(name: String, description: String) {
    Card(
        onClick = { /* Handle selection */ },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = name, style = MaterialTheme.typography.titleLarge)
            Text(text = description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
