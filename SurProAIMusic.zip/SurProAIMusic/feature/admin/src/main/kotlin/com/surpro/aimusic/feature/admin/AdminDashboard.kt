package com.surpro.aimusic.feature.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AdminDashboard() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Admin Panel", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { AdminStatCard("Total Users", "1,234") }
            item { AdminStatCard("Revenue", "৳45,000") }
            item { AdminStatCard("Pending Payments", "12") }
            item { AdminStatCard("API Costs", "$156.00") }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(onClick = { /* User Management */ }, modifier = Modifier.fillMaxWidth()) {
            Text("User Management")
        }
        Button(onClick = { /* Plan Management */ }, modifier = Modifier.fillMaxWidth()) {
            Text("Plan & Pricing Management")
        }
    }
}

@Composable
fun AdminStatCard(label: String, value: String) {
    Card {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelMedium)
            Text(text = value, style = MaterialTheme.typography.headlineSmall)
        }
    }
}
