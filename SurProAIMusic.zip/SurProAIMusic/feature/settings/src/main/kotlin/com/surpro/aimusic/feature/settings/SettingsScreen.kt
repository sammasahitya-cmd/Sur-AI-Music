package com.surpro.aimusic.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "App Settings", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        ListItem(
            headlineContent = { Text("Dark Mode") },
            trailingContent = { Switch(checked = true, onCheckedChange = {}) }
        )
        
        ListItem(
            headlineContent = { Text("App Language") },
            supportingContent = { Text("Bengali / English") }
        )
        
        ListItem(
            headlineContent = { Text("Audio Quality") },
            supportingContent = { Text("320kbps (Pro)") }
        )
        
        Divider()
        
        Text(
            text = "Appearance",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Color picker items
            ColorCircle(androidx.compose.ui.graphics.Color.Blue)
            ColorCircle(androidx.compose.ui.graphics.Color.Red)
            ColorCircle(androidx.compose.ui.graphics.Color.Green)
            ColorCircle(androidx.compose.ui.graphics.Color.Magenta)
        }
    }
}

@Composable
fun ColorCircle(color: androidx.compose.ui.graphics.Color) {
    Surface(
        modifier = Modifier.size(40.dp),
        shape = androidx.compose.foundation.shape.CircleShape,
        color = color
    ) {}
}
