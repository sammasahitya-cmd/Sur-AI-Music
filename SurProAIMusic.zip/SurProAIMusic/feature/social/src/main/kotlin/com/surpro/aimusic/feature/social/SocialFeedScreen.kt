package com.surpro.aimusic.feature.social

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SocialFeedScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(10) {
            SocialPostCard()
        }
    }
}

@Composable
fun SocialPostCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Artist Name", style = MaterialTheme.typography.titleMedium)
            Text(text = "Generated a new Pop track using Suno v4", style = MaterialTheme.typography.bodySmall)
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Audio player placeholder
            Surface(
                modifier = Modifier.fillMaxWidth().height(60.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = MaterialTheme.shapes.medium
            ) {
                Text(text = "Audio Player Placeholder", modifier = Modifier.padding(16.dp))
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row {
                IconButton(onClick = {}) { Icon(Icons.Default.Favorite, "Like") }
                IconButton(onClick = {}) { Icon(Icons.Default.Share, "Share") }
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = {}) { Text("Remix") }
            }
        }
    }
}
