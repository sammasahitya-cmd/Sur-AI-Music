package com.surpro.aimusic.feature.music

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicGenScreen() {
    var prompt by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Pop") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "AI Music Generator", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Describe your music") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(text = "Select Genre")
        // Add genre selection logic...
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = { /* Call VM generate */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Generate Music (Suno v4)")
        }
    }
}
