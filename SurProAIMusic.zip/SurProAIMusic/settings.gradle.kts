rootProject.name = "SurPro AI Music"

include(":app")
include(":core")
include(":data")
include(":domain")

// Feature modules
include(":feature:auth")
include(":feature:music")
include(":feature:lyrics")
include(":feature:social")
include(":feature:marketplace")
include(":feature:admin")
include(":feature:payment")
include(":feature:settings")
include(":feature:video")
