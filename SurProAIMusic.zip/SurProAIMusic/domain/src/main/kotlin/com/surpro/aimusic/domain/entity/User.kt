package com.surpro.aimusic.domain.entity

data class User(
    val id: String,
    val email: String,
    val plan: UserPlan,
    val tokens: Int,
    val lyricsLimit: Int
)

enum class UserPlan {
    FREE, STARTER, PRO, ULTRA, STUDIO
}

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val url: String,
    val createdAt: Long
)

data class Lyrics(
    val id: String,
    val title: String,
    val content: String,
    val language: String,
    val createdAt: Long
)
