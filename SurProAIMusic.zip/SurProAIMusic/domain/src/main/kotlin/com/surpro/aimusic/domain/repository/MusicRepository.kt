package com.surpro.aimusic.domain.repository

import com.surpro.aimusic.domain.entity.MusicTrack
import com.surpro.aimusic.domain.entity.Lyrics
import kotlinx.coroutines.flow.Flow

interface MusicRepository {
    suspend fun generateMusic(prompt: String, genre: String): Result<MusicTrack>
    suspend fun getTracks(): Flow<List<MusicTrack>>
    suspend fun getTrackById(id: String): MusicTrack?
}

interface LyricsRepository {
    suspend fun generateLyrics(prompt: String, language: String): Result<Lyrics>
    suspend fun getLyricsHistory(): Flow<List<Lyrics>>
}
