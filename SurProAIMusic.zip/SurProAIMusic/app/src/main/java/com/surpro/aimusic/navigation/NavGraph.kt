package com.surpro.aimusic.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.surpro.aimusic.MainScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Auth : Screen("auth")
    object MusicGen : Screen("music_gen")
    object LyricsGen : Screen("lyrics_gen")
    object Social : Screen("social")
    object Marketplace : Screen("marketplace")
    object Profile : Screen("profile")
    object Admin : Screen("admin")
    object Payment : Screen("payment")
}

@Composable
fun SetupNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(route = Screen.Home.route) {
            MainScreen()
        }
        composable(route = Screen.Auth.route) {
            // AuthScreen()
        }
        composable(route = Screen.MusicGen.route) {
            // MusicGenScreen()
        }
        // Add other screens...
    }
}
