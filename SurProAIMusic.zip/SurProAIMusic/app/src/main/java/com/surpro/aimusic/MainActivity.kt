package com.surpro.aimusic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.surpro.aimusic.core.components.BottomNavItem
import com.surpro.aimusic.core.components.BottomNavBar
import com.surpro.aimusic.core.theme.SurProTheme
import com.surpro.aimusic.navigation.Screen
import com.surpro.aimusic.navigation.SetupNavGraph
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SurProTheme {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                Scaffold(
                    bottomBar = {
                        BottomNavBar(
                            items = listOf(
                                BottomNavItem("Home", Screen.Home.route, Icons.Default.Home),
                                BottomNavItem("Music", Screen.MusicGen.route, Icons.Default.LibraryMusic),
                                BottomNavItem("Social", Screen.Social.route, Icons.Default.Public),
                                BottomNavItem("Profile", Screen.Profile.route, Icons.Default.Person),
                            ),
                            currentRoute = currentRoute,
                            onItemClick = { navController.navigate(it.route) }
                        )
                    }
                ) { padding ->
                    Modifier.padding(padding).also {
                        SetupNavGraph(navController = navController)
                    }
                }
            }
        }
    }
}
