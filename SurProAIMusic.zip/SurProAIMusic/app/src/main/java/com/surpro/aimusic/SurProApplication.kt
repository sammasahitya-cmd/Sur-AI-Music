package com.surpro.aimusic

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SurProApplication : Application()
