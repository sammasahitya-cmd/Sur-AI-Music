package com.surpro.aimusic.data.model

import kotlinx.serialization.Serializable

@Serializable
data class MusicDto(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val url: String,
    val created_at: String
)

@Serializable
data class LyricsDto(
    val id: String,
    val title: String,
    val content: String,
    val language: String,
    val created_at: String
)
