package com.surpro.aimusic.data.repository

import com.surpro.aimusic.data.model.MusicDto
import com.surpro.aimusic.domain.entity.MusicTrack
import com.surpro.aimusic.domain.repository.MusicRepository
import io.github.jan_tennert.supabase.postgrest.Postgrest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class MusicRepositoryImpl @Inject constructor(
    private val postgrest: Postgrest
) : MusicRepository {

    override suspend fun generateMusic(prompt: String, genre: String): Result<MusicTrack> {
        // Implementation for AI generation via API
        return Result.failure(Exception("Not implemented"))
    }

    override suspend fun getTracks(): Flow<List<MusicTrack>> = flow {
        val result = postgrest["music_tracks"].select().decodeList<MusicDto>()
        emit(result.map { it.toDomain() })
    }

    override suspend fun getTrackById(id: String): MusicTrack? {
        return postgrest["music_tracks"].select {
            filter {
                eq("id", id)
            }
        }.decodeSingleOrNull<MusicDto>()?.toDomain()
    }

    private fun MusicDto.toDomain() = MusicTrack(
        id = id,
        title = title,
        artist = artist,
        genre = genre,
        url = url,
        createdAt = 0L // Parse date string to long
    )
}
